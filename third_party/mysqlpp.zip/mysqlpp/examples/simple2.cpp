/***********************************************************************
 simple2.cpp - Retrieves the entire contents of the sample stock table
	using a "store" query, and prints it out.

 Copyright (c) 1998 by Kevin Atkinson, (c) 1999-2001 by MySQL AB, and
 (c) 2004-2009 by Educational Technology Resources, Inc.  Others may
 also hold copyrights on code in this file.  See the CREDITS.txt file
 in the top directory of the distribution for details.

 This file is part of MySQL++.

 MySQL++ is free software; you can redistribute it and/or modify it
 under the terms of the GNU Lesser General Public License as published
 by the Free Software Foundation; either version 2.1 of the License, or
 (at your option) any later version.

 MySQL++ is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with MySQL++; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301
 USA
***********************************************************************/

#include "cmdline.h"
#include "printdata.h"

#include <mysql++.h>

#include <iostream>
#include <iomanip>
using namespace std;

/*
int utf8tounicode(const char *utf8_buf, char *unicode_buf, int max_unicode_buf_size)
{
	memset( unicode_buf , 0 , max_unicode_buf_size );
	unsigned short *uni_ptr = (unsigned short *)unicode_buf;
	const unsigned char *utf_ptr = (const unsigned char *)utf8_buf;
	unsigned short word;
	unsigned char ch;
	unsigned int uni_ind = 0, utf_ind = 0, utf_num = 0;

	while(1)
	{
		ch = *(utf_ptr + utf_ind);

		if(ch == 0x00) //������
			break;

		if ((ch & 0x80) == 0) 
		{
			*(uni_ptr + uni_ind) = *(utf_ptr + utf_ind);
			uni_ind++;

			utf_ind++;
			utf_num++;
		} 
		else if((ch & 0xE0) == 0xC0)  ///< 110x-xxxx 10xx-xxxx
		{
			word = (*(utf_ptr + utf_ind) & 0x3F) << 6;
			word |= (*(utf_ptr + utf_ind + 1) & 0x3F);

			*(uni_ptr + uni_ind) = word;
			uni_ind++;

			utf_ind += 2;
			utf_num++;
		}
		else if((ch & 0xF0) == 0xE0)  ///< 1110-xxxx 10xx-xxxx 10xx-xxxx
		{
			word = (*(utf_ptr + utf_ind) & 0x1F) << 12;
			word |= (*(utf_ptr + utf_ind + 1) & 0x3F) << 6;
			word |= (*(utf_ptr + utf_ind + 2) & 0x3F);

			*(uni_ptr + uni_ind) = word;
			uni_ind++;

			utf_ind += 3;
			utf_num++;
		} 
		else if((ch & 0xF8) == 0xF0)  ///< 1111-0xxx 10xx-xxxx 10xx-xxxx 10xx-xxxx 
		{
			word = (*(utf_ptr + utf_ind) & 0x0F) << 18;
			word = (*(utf_ptr + utf_ind + 1) & 0x3F) << 12;
			word |= (*(utf_ptr + utf_ind + 2) & 0x3F) << 6;
			word |= (*(utf_ptr + utf_ind + 3) & 0x3F);

			*(uni_ptr + uni_ind) = word;
			uni_ind++;

			utf_ind += 4;
			utf_num++;
		} 
		else   ///< 1111-10xx 10xx-xxxx 10xx-xxxx 10xx-xxxx 10xx-xxxx 
		{
			word = (*(utf_ptr + utf_ind) & 0x07) << 24;
			word = (*(utf_ptr + utf_ind + 1) & 0x3F) << 18;
			word = (*(utf_ptr + utf_ind + 2) & 0x3F) << 12;
			word = (*(utf_ptr + utf_ind + 3) & 0x3F) << 6;
			word = (*(utf_ptr + utf_ind + 4) & 0x3F);

			*(uni_ptr + uni_ind) = word;
			uni_ind++;

			utf_ind += 5;
			utf_num++;
		}

		if(utf_num*2 > (unsigned int)(max_unicode_buf_size - 1))
		{
			break;
		}
	}
	*(uni_ptr + uni_ind) = '\0';

	return utf_num;
}

void unicode_to_gb2312(const wchar_t* wzBufIn,char* szBufOut,int nMaxLen)
{
	int len = WideCharToMultiByte(CP_ACP, 0, wzBufIn, -1, NULL, 0, NULL, NULL);
	if (len == 0 || len > nMaxLen)
	{
		printf("len error : %d",len);
		return;
	}

	WideCharToMultiByte(CP_ACP, 0, wzBufIn, -1, szBufOut, len, NULL, NULL);
}

int unicodetoutf8(LPCWSTR lpwzSrc,LPSTR lpszOut,int nSizeMax)
{
	int nSrcLen = (int)wcslen(lpwzSrc);
	int nLen = WideCharToMultiByte(CP_UTF8, 0, lpwzSrc, nSrcLen, NULL, 0, NULL, NULL);

	if (nLen > nSizeMax)
	{
		return -1;
	}

	WideCharToMultiByte(CP_UTF8, 0, lpwzSrc, nSrcLen , lpszOut, nLen , NULL, NULL);

	return 0;
}
*/
int
main(int argc, char *argv[])
{
	// Get database access parameters from command line
	mysqlpp::examples::CommandLine cmdline(argc, argv);
	if (!cmdline) {
		return 1;
	}

	// Connect to the sample database.
	mysqlpp::Connection conn(false);
	if (conn.connect("youturn.newslggame","192.168.1.22","root","aptx4869")) 
	{
		// Retrieve the sample stock table set up by resetdb
		mysqlpp::Query query = conn.query("call p_test(123,23123);");
		mysqlpp::StoreQueryResult res = query.store();

		// Display results
		if (res) {
			// Display header
			cout.setf(ios::left);
			cout << setw(31) << "Item" <<
					setw(10) << "Num" <<
					setw(10) << "Weight" <<
					setw(10) << "Price" <<
					"Date" << endl << endl;

			// Get each row in result set, and print its contents
			for (size_t i = 0; i < res.num_rows(); ++i) {
				cout << setw(30) << res[i]["item"] << ' ' <<
						setw(9) << res[i]["num"] << ' ' <<
						setw(9) << res[i]["weight"] << ' ' <<
						setw(9) << res[i]["price"] << ' ' <<
						setw(9) << res[i]["sdate"] <<
						endl;
			}
		}
		else {
			cerr << "Failed to get stock table: " << query.error() << endl;
			return 1;
		}

		return 0;
	}
	else {
		cerr << "DB connection failed: " << conn.error() << endl;
		return 1;
	}
	/*
		mysqlpp::Connection conn(false);

		conn.set_option(new mysqlpp::MultiResultsOption(true));
		conn.set_option(new mysqlpp::ReconnectOption(true));
		conn.set_option(new mysqlpp::SetCharsetNameOption("gb2312"));

		conn.connect("youturn.newslggame.test","192.168.1.22","root","aptx4869",3306);

		mysqlpp::Query qu = conn.query("call p_test(120294);");

		bool succ =qu.store_only_execute();

		vector<mysqlpp::StoreQueryResult> vctQueryRes;

		if (succ)
		{
		// 		mysqlpp::StoreQueryResult res = qu.store_result();
		// 		do
		// 		{
		// 			for (size_t i = 0; i < res.field_names()->size(); i++)
		// 			{
		// 				printf_s("%s\t",res.field_name(int(i)).c_str());
		// 			}
		// 			printf_s("\n");
		// 			for (mysqlpp::StoreQueryResult::size_type i = 0; i < res.size(); ++i)
		// 			{
		// 				for (int j = 0; j < res[i].size(); ++j)
		// 				{
		// 					printf_s("\t");
		// 				}
		//
		// 				printf_s("\n");
		// 			}
		//
		// 			res = qu.store_next();
		// 		} while (qu.more_results());
		mysqlpp::StoreQueryResult res = qu.store_result();
		vctQueryRes.push_back(res);
		while (qu.more_results())
		{
		vctQueryRes.push_back(qu.store_next());
		}
		}
		else
		{
		int nerr = qu.errnum();
		printf_s("Error : %d[%s]",nerr,qu.error());
		}
	*/
	return 0;
}
