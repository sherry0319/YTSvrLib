var searchData=
[
  ['error',['error',['../classcpp__redis_1_1reply.html#acc272b2a52164cac1d110c619a0b25bdacb5e100e5a9a3e7f6d1fd97512215282',1,'cpp_redis::reply::error()'],['../classcpp__redis_1_1reply.html#ac192ba4cb8f2bb6e7cb465edf755328bacb5e100e5a9a3e7f6d1fd97512215282',1,'cpp_redis::reply::error()'],['../classcpp__redis_1_1logger.html#a9493594d547e7abe71b8690be1946c7aacb5e100e5a9a3e7f6d1fd97512215282',1,'cpp_redis::logger::error()']]]
];
