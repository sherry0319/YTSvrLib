var searchData=
[
  ['logger',['logger',['../classcpp__redis_1_1logger.html#a36b15a75690a087fca7d304852785512',1,'cpp_redis::logger::logger(log_level level=log_level::info)'],['../classcpp__redis_1_1logger.html#aec0854d47a13f91e09db25e745a3d722',1,'cpp_redis::logger::logger(const logger &amp;)=default']]],
  ['logger_5fiface',['logger_iface',['../classcpp__redis_1_1logger__iface.html#a902e41bf0777b960b6575e7ac986147b',1,'cpp_redis::logger_iface::logger_iface(void)=default'],['../classcpp__redis_1_1logger__iface.html#a7f1cb271b18e40f2dde7e45028e69a84',1,'cpp_redis::logger_iface::logger_iface(const logger_iface &amp;)=default']]]
];
