var searchData=
[
  ['string_5ftype',['string_type',['../classcpp__redis_1_1reply.html#ac192ba4cb8f2bb6e7cb465edf755328b',1,'cpp_redis::reply']]]
];
